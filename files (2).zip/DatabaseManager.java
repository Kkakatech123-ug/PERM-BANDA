package permbandaschurch.dao;

import java.sql.*;

/**
 * SQLite DatabaseManager — creates all PERM BANDA CHURCH tables.
 * Database file: permbandaschurch.db (created in project root)
 */
public class DatabaseManager {

    private static final String DB_URL = "jdbc:sqlite:permbandaschurch.db";
    private static DatabaseManager instance;
    private Connection connection;

    private DatabaseManager() {}

    public static DatabaseManager getInstance() {
        if (instance == null) instance = new DatabaseManager();
        return instance;
    }

    public Connection getConnection() throws SQLException {
        if (connection == null || connection.isClosed()) {
            connection = DriverManager.getConnection(DB_URL);
            connection.createStatement().execute("PRAGMA foreign_keys = ON");
        }
        return connection;
    }

    public void initializeDatabase() {
        try (Statement stmt = getConnection().createStatement()) {

            // ── Admins ────────────────────────────────────────────────────
            stmt.execute("""
                CREATE TABLE IF NOT EXISTS admins (
                    id       INTEGER PRIMARY KEY AUTOINCREMENT,
                    username TEXT NOT NULL UNIQUE,
                    password TEXT NOT NULL,
                    email    TEXT,
                    role     TEXT DEFAULT 'admin'
                )
            """);

            // ── Members (synced from Android registrations) ───────────────
            stmt.execute("""
                CREATE TABLE IF NOT EXISTS members (
                    id        INTEGER PRIMARY KEY AUTOINCREMENT,
                    name      TEXT NOT NULL,
                    email     TEXT UNIQUE,
                    phone     TEXT,
                    ministry  TEXT,
                    joined    TEXT DEFAULT CURRENT_TIMESTAMP
                )
            """);

            // ── Sermons ───────────────────────────────────────────────────
            stmt.execute("""
                CREATE TABLE IF NOT EXISTS sermons (
                    id          INTEGER PRIMARY KEY AUTOINCREMENT,
                    title       TEXT NOT NULL,
                    preacher    TEXT NOT NULL,
                    date        TEXT NOT NULL,
                    category    TEXT,
                    media_type  TEXT,
                    media_url   TEXT,
                    description TEXT,
                    created     TEXT DEFAULT CURRENT_TIMESTAMP
                )
            """);

            // ── Giving / Transactions ─────────────────────────────────────
            stmt.execute("""
                CREATE TABLE IF NOT EXISTS givings (
                    id             INTEGER PRIMARY KEY AUTOINCREMENT,
                    member_name    TEXT NOT NULL,
                    phone          TEXT NOT NULL,
                    amount_ugx     REAL NOT NULL,
                    giving_type    TEXT NOT NULL,
                    payment_method TEXT NOT NULL,
                    transaction_id TEXT,
                    status         TEXT DEFAULT 'PENDING',
                    created        TEXT DEFAULT CURRENT_TIMESTAMP
                )
            """);

            // ── Prayer Requests ───────────────────────────────────────────
            stmt.execute("""
                CREATE TABLE IF NOT EXISTS prayer_requests (
                    id           INTEGER PRIMARY KEY AUTOINCREMENT,
                    member_name  TEXT NOT NULL,
                    category     TEXT NOT NULL,
                    request      TEXT NOT NULL,
                    visibility   TEXT DEFAULT 'private',
                    status       TEXT DEFAULT 'PENDING',
                    admin_note   TEXT,
                    created      TEXT DEFAULT CURRENT_TIMESTAMP
                )
            """);

            // ── Ministries ────────────────────────────────────────────────
            stmt.execute("""
                CREATE TABLE IF NOT EXISTS ministries (
                    id          INTEGER PRIMARY KEY AUTOINCREMENT,
                    name        TEXT NOT NULL,
                    description TEXT,
                    leader      TEXT,
                    image_url   TEXT,
                    updated     TEXT DEFAULT CURRENT_TIMESTAMP
                )
            """);

            // ── Church Updates ────────────────────────────────────────────
            stmt.execute("""
                CREATE TABLE IF NOT EXISTS updates (
                    id      INTEGER PRIMARY KEY AUTOINCREMENT,
                    title   TEXT NOT NULL,
                    body    TEXT NOT NULL,
                    created TEXT DEFAULT CURRENT_TIMESTAMP
                )
            """);

            seedData(stmt);
            System.out.println("PERM BANDA CHURCH DB initialised.");

        } catch (SQLException e) {
            System.err.println("DB Error: " + e.getMessage());
        }
    }

    private void seedData(Statement stmt) throws SQLException {
        ResultSet rs = stmt.executeQuery("SELECT COUNT(*) FROM admins");
        if (rs.getInt(1) > 0) return;

        // Admin accounts
        stmt.execute("INSERT INTO admins(username,password,email,role) VALUES('admin','permchurch2024','admin@permbandaschurch.org','superadmin')");
        stmt.execute("INSERT INTO admins(username,password,email,role) VALUES('pastor','pastor123','pastor@permbandaschurch.org','pastor')");

        // Ministries
        stmt.execute("INSERT INTO ministries(name,description,leader) VALUES('Children''s Ministry','Nurturing young believers in faith','Sister Grace Auma')");
        stmt.execute("INSERT INTO ministries(name,description,leader) VALUES('Youth Ministry','Empowering the next generation','Pr. David Wamala')");
        stmt.execute("INSERT INTO ministries(name,description,leader) VALUES('Women''s Ministry','Fellowship and spiritual growth for women','Deaconess Ruth Nalwoga')");
        stmt.execute("INSERT INTO ministries(name,description,leader) VALUES('Men''s Ministry','Men of God walking in purpose','Elder James Otim')");
        stmt.execute("INSERT INTO ministries(name,description,leader) VALUES('Praise & Worship','Leading the congregation in worship','Bro. Solomon Kirya')");

        // Sample sermons
        stmt.execute("INSERT INTO sermons(title,preacher,date,category,media_type,description) VALUES('Walking by Faith','Rev. Dr. Emmanuel Akatukunda','2024-01-14','Faith','Audio','A powerful message on trusting God in all circumstances.')");
        stmt.execute("INSERT INTO sermons(title,preacher,date,category,media_type,description) VALUES('The Power of Prayer','Pr. Gideon Onyait','2024-01-21','Prayer','Video','Understanding how prayer transforms lives.')");
        stmt.execute("INSERT INTO sermons(title,preacher,date,category,media_type,description) VALUES('Grace and Redemption','Rev. Dr. Emmanuel Akatukunda','2024-01-28','Salvation','Audio','God''s amazing grace in the life of a believer.')");

        // Church update
        stmt.execute("INSERT INTO updates(title,body) VALUES('Sunday Service Times','Join us every Sunday at 9:00 AM and 11:00 AM for powerful worship services.')");
        stmt.execute("INSERT INTO updates(title,body) VALUES('Youth Conference 2024','The annual youth conference is coming up. Register at the church office.')");
    }
}
