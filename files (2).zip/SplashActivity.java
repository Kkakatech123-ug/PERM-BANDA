package com.permbandaschurch.activities;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import androidx.appcompat.app.AppCompatActivity;
import com.permbandaschurch.R;
import com.permbandaschurch.utils.SessionManager;

/**
 * Splash screen — shown for 2.5s then routes to Login or Home.
 */
public class SplashActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);

        new Handler().postDelayed(() -> {
            SessionManager session = new SessionManager(this);
            Intent intent = session.isLoggedIn()
                ? new Intent(this, HomeActivity.class)
                : new Intent(this, LoginActivity.class);
            startActivity(intent);
            finish();
        }, 2500);
    }
}
