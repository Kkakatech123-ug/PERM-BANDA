package permbandaschurch.dao;

import permbandaschurch.model.*;
import java.sql.*;
import java.util.*;

// ═══════════════════════════════════════════════════════════════
//  SermonDAO
// ═══════════════════════════════════════════════════════════════
public class SermonDAO {
    private Connection conn() throws SQLException {
        return DatabaseManager.getInstance().getConnection();
    }

    public List<Sermon> getAll() {
        List<Sermon> list = new ArrayList<>();
        try (Statement st = conn().createStatement();
             ResultSet rs = st.executeQuery("SELECT * FROM sermons ORDER BY date DESC")) {
            while (rs.next()) list.add(map(rs));
        } catch (SQLException e) { e.printStackTrace(); }
        return list;
    }

    public List<Sermon> search(String query) {
        List<Sermon> list = new ArrayList<>();
        String sql = "SELECT * FROM sermons WHERE LOWER(title) LIKE ? OR LOWER(preacher) LIKE ? OR LOWER(category) LIKE ?";
        try (PreparedStatement ps = conn().prepareStatement(sql)) {
            String q = "%" + query.toLowerCase() + "%";
            ps.setString(1,q); ps.setString(2,q); ps.setString(3,q);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) list.add(map(rs));
        } catch (SQLException e) { e.printStackTrace(); }
        return list;
    }

    public boolean add(Sermon s) {
        String sql = "INSERT INTO sermons(title,preacher,date,category,media_type,media_url,description) VALUES(?,?,?,?,?,?,?)";
        try (PreparedStatement ps = conn().prepareStatement(sql)) {
            ps.setString(1,s.getTitle()); ps.setString(2,s.getPreacher());
            ps.setString(3,s.getDate()); ps.setString(4,s.getCategory());
            ps.setString(5,s.getMediaType()); ps.setString(6,s.getMediaUrl());
            ps.setString(7,s.getDescription()); ps.executeUpdate(); return true;
        } catch (SQLException e) { e.printStackTrace(); return false; }
    }

    public boolean update(Sermon s) {
        String sql = "UPDATE sermons SET title=?,preacher=?,date=?,category=?,media_type=?,media_url=?,description=? WHERE id=?";
        try (PreparedStatement ps = conn().prepareStatement(sql)) {
            ps.setString(1,s.getTitle()); ps.setString(2,s.getPreacher());
            ps.setString(3,s.getDate()); ps.setString(4,s.getCategory());
            ps.setString(5,s.getMediaType()); ps.setString(6,s.getMediaUrl());
            ps.setString(7,s.getDescription()); ps.setInt(8,s.getId());
            ps.executeUpdate(); return true;
        } catch (SQLException e) { e.printStackTrace(); return false; }
    }

    public boolean delete(int id) {
        try (PreparedStatement ps = conn().prepareStatement("DELETE FROM sermons WHERE id=?")) {
            ps.setInt(1,id); ps.executeUpdate(); return true;
        } catch (SQLException e) { e.printStackTrace(); return false; }
    }

    private Sermon map(ResultSet rs) throws SQLException {
        return new Sermon(rs.getInt("id"), rs.getString("title"), rs.getString("preacher"),
            rs.getString("date"), rs.getString("category"), rs.getString("media_type"),
            rs.getString("media_url"), rs.getString("description"));
    }
}
