package com.permbandaschurch.network;

import android.os.Handler;
import android.os.Looper;
import java.util.UUID;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * PaymentService — handles MTN MoMo and Airtel Money API calls.
 *
 * PRODUCTION SETUP:
 *  1. Replace BASE_URL_MTN / BASE_URL_AIRTEL with live endpoints
 *  2. Add your real API credentials to the request headers
 *  3. Remove the demo simulation block at the bottom
 *
 * MTN MoMo Docs:   https://momodeveloper.mtn.com
 * Airtel Money Docs: https://developers.airtel.africa
 */
public class PaymentService {

    // ── API Base URLs ─────────────────────────────────────────────────────────
    private static final String BASE_URL_MTN    = "https://sandbox.momodeveloper.mtn.com";
    private static final String BASE_URL_AIRTEL = "https://openapiuat.airtel.africa";

    // ── Target accounts ───────────────────────────────────────────────────────
    public static final String MTN_RECEIVER    = "25676334436";    // Okurut Ambrose
    public static final String AIRTEL_RECEIVER = "256756334436";   // Okurut Ambrose

    private static final ExecutorService executor = Executors.newSingleThreadExecutor();
    private static final Handler        mainThread = new Handler(Looper.getMainLooper());

    public interface PaymentCallback {
        void onSuccess(String transactionId);
        void onFailure(String error);
    }

    // ─────────────────────────────────────────────────────────────────────────
    //  Main entry: route by provider
    // ─────────────────────────────────────────────────────────────────────────
    public static void initiatePayment(String customerPhone, double amount,
                                       String description, String provider,
                                       String targetAccount, PaymentCallback cb) {
        executor.execute(() -> {
            try {
                String txnId;
                if ("MTN".equals(provider)) {
                    txnId = initiateMtnPayment(customerPhone, amount, description);
                } else {
                    txnId = initiateAirtelPayment(customerPhone, amount, description);
                }
                mainThread.post(() -> cb.onSuccess(txnId));
            } catch (Exception e) {
                mainThread.post(() -> cb.onFailure(e.getMessage()));
            }
        });
    }

    // ─────────────────────────────────────────────────────────────────────────
    //  MTN MoMo — Request to Pay
    // ─────────────────────────────────────────────────────────────────────────
    private static String initiateMtnPayment(String phone, double amount,
                                              String desc) throws Exception {
        // PRODUCTION: Use OkHttp / Retrofit to call the real MTN API
        // Steps:
        //   1. POST /collection/token/ → get access_token
        //   2. POST /collection/v1_0/requesttopay with X-Reference-Id header
        //   3. GET  /collection/v1_0/requesttopay/{referenceId} to poll status

        /*
         * REAL REQUEST BODY (JSON):
         * {
         *   "amount": "50000",
         *   "currency": "UGX",
         *   "externalId": "ORDER-001",
         *   "payer": { "partyIdType": "MSISDN", "partyId": "256780123456" },
         *   "payerMessage": "Tithe — PERM BANDA CHURCH",
         *   "payeeNote": "Thank you for giving"
         * }
         *
         * HEADERS:
         *   Authorization: Bearer {access_token}
         *   X-Reference-Id: {UUID}
         *   X-Target-Environment: sandbox / production
         *   Ocp-Apim-Subscription-Key: {your_subscription_key}
         */

        // ── DEMO SIMULATION (remove in production) ────────────────────────
        Thread.sleep(2000); // Simulate network delay
        return "MTN-" + UUID.randomUUID().toString().substring(0, 8).toUpperCase();
        // ── END DEMO ──────────────────────────────────────────────────────
    }

    // ─────────────────────────────────────────────────────────────────────────
    //  Airtel Money — Initiate Payment
    // ─────────────────────────────────────────────────────────────────────────
    private static String initiateAirtelPayment(String phone, double amount,
                                                 String desc) throws Exception {
        // PRODUCTION: Use OkHttp / Retrofit to call the real Airtel API
        // Steps:
        //   1. POST /auth/oauth2/token → get access_token
        //   2. POST /merchant/v1/payments/ with transaction body
        //   3. GET  /standard/v1/payments/{transaction_id} to poll status

        /*
         * REAL REQUEST BODY (JSON):
         * {
         *   "reference": "Tithe — PERM BANDA CHURCH",
         *   "subscriber": {
         *     "country": "UG",
         *     "currency": "UGX",
         *     "msisdn": "256755123456"
         *   },
         *   "transaction": {
         *     "amount": 50000,
         *     "country": "UG",
         *     "currency": "UGX",
         *     "id": "{UUID}"
         *   }
         * }
         *
         * HEADERS:
         *   Authorization: Bearer {access_token}
         *   X-Country: UG
         *   X-Currency: UGX
         */

        // ── DEMO SIMULATION (remove in production) ────────────────────────
        Thread.sleep(2000);
        return "AIRTEL-" + UUID.randomUUID().toString().substring(0, 8).toUpperCase();
        // ── END DEMO ──────────────────────────────────────────────────────
    }
}
