package permbandaschurch.ui;

import permbandaschurch.dao.*;
import permbandaschurch.model.*;
import permbandaschurch.util.*;
import javafx.collections.*;
import javafx.geometry.*;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.*;
import javafx.scene.text.*;
import javafx.stage.Stage;
import java.util.*;

public class AdminDashboard {

    private final Stage      stage;
    private final SermonDAO  sermonDAO  = new SermonDAO();
    private final GivingDAO  givingDAO  = new GivingDAO();
    private final PrayerDAO  prayerDAO  = new PrayerDAO();
    private final MinistryDAO ministryDAO = new MinistryDAO();
    private final Session    session    = Session.getInstance();

    public AdminDashboard(Stage stage) { this.stage = stage; }

    public void show() {
        stage.setTitle("PERM BANDA CHURCH — Admin Dashboard");

        BorderPane root = new BorderPane();
        root.setStyle("-fx-background-color:" + UIHelper.BG_LIGHT + ";");
        root.setTop(buildNavBar());
        root.setCenter(buildTabs());

        stage.setScene(new Scene(root, 1100, 720));
        stage.centerOnScreen();
        stage.show();
    }

    // ── Nav Bar ───────────────────────────────────────────────────────────────
    private HBox buildNavBar() {
        HBox nav = new HBox(14);
        nav.setAlignment(Pos.CENTER_LEFT);
        nav.setPadding(new Insets(10, 20, 10, 20));
        nav.setStyle("-fx-background-color:" + UIHelper.DEEP_NAVY + ";");

        Label cross = new Label("✝");
        cross.setFont(Font.font("System", 20));
        cross.setStyle("-fx-text-fill:" + UIHelper.GOLD + ";");

        Label name = new Label("PERM BANDA CHURCH");
        name.setFont(Font.font("System", FontWeight.BOLD, 16));
        name.setStyle("-fx-text-fill:" + UIHelper.GOLD + ";");

        Label sub = new Label("Admin Panel");
        sub.setStyle("-fx-text-fill:#8aadce; -fx-font-size:12px;");

        Region spacer = new Region();
        HBox.setHgrow(spacer, Priority.ALWAYS);

        Label adminLabel = new Label("👤 " + session.getCurrentAdmin().getUsername());
        adminLabel.setStyle("-fx-text-fill:#a0b8d0;");

        Label roleBadge = UIHelper.badge(
            session.getCurrentAdmin().getRole().toUpperCase(),
            UIHelper.GOLD, UIHelper.DEEP_NAVY);

        Button logoutBtn = UIHelper.dangerButton("Logout");
        logoutBtn.setOnAction(e -> { session.logout(); new LoginScreen(stage).show(); });

        nav.getChildren().addAll(cross, name, sub, spacer, adminLabel, roleBadge, logoutBtn);
        return nav;
    }

    // ── Tabs ──────────────────────────────────────────────────────────────────
    private TabPane buildTabs() {
        TabPane tabs = new TabPane();
        tabs.setTabClosingPolicy(TabPane.TabClosingPolicy.UNAVAILABLE);
        tabs.getTabs().addAll(
            new Tab("📊  Overview",         buildOverviewTab()),
            new Tab("🎙  Sermons",           buildSermonsTab()),
            new Tab("💛  Giving",            buildGivingTab()),
            new Tab("🙏  Prayer Requests",   buildPrayerTab()),
            new Tab("⛪  Ministries",         buildMinistriesTab()),
            new Tab("👑  Leadership",         buildLeadershipTab())
        );
        return tabs;
    }

    // ── OVERVIEW TAB ──────────────────────────────────────────────────────────
    private VBox buildOverviewTab() {
        VBox pane = new VBox(20);
        pane.setPadding(new Insets(24));

        Label title = UIHelper.heading("✝  Church Overview");

        int    totalSermons  = sermonDAO.getAll().size();
        double totalGiving   = givingDAO.getGrandTotal();
        int    pendingPrayer = prayerDAO.countPending();
        int    totalMinistry = ministryDAO.getAll().size();

        HBox stats = new HBox(16,
            UIHelper.statCard("Total Sermons",    String.valueOf(totalSermons), UIHelper.ROYAL_BLUE),
            UIHelper.statCard("Total Offerings",  String.format("UGX %,.0f", totalGiving), UIHelper.GOLD),
            UIHelper.statCard("Prayer Requests",  String.valueOf(pendingPrayer) + " pending", UIHelper.DANGER),
            UIHelper.statCard("Ministries",       String.valueOf(totalMinistry), UIHelper.SUCCESS)
        );

        // Recent giving summary
        Label giveTitle = UIHelper.subheading("Giving Summary by Type");
        String[] types = {"Tithe","Offering","Donation","Thanksgiving","First Fruit Offering"};
        VBox giveSummary = new VBox(6);
        for (String type : types) {
            double amt = givingDAO.getTotalByType(type);
            HBox row = new HBox(10);
            row.setAlignment(Pos.CENTER_LEFT);
            Label typeLabel = new Label(type);
            typeLabel.setPrefWidth(200);
            Label amtLabel = new Label(String.format("UGX %,.0f", amt));
            amtLabel.setStyle("-fx-font-weight:bold; -fx-text-fill:" + UIHelper.ROYAL_BLUE + ";");
            row.getChildren().addAll(typeLabel, amtLabel);
            giveSummary.getChildren().add(row);
        }

        // Leadership Quick Reference
        Label leadTitle = UIHelper.subheading("Leadership Quick Reference");
        VBox leadBox = UIHelper.card(
            new Label("✝  Senior Pastor: Rev. Dr. Emmanuel Akatukunda"),
            new Label("     📞 +256706062966  |  +256788758696"),
            new Label(""),
            new Label("✝  Assistant Pastor: Pr. Gideon Onyait"),
            new Label("     📞 +256772566848  |  +256754247261"),
            new Label(""),
            new Label("💰 MTN MoMo: +25676334436  (Okurut Ambrose)"),
            new Label("💰 Airtel Money: +256756334436  (Okurut Ambrose)")
        );

        pane.getChildren().addAll(title, stats, UIHelper.separator(), giveTitle, giveSummary,
            UIHelper.separator(), leadTitle, leadBox);
        return pane;
    }

    private VBox card(javafx.scene.Node... nodes) {
        VBox box = new VBox(6, nodes);
        box.setPadding(new Insets(14));
        box.setStyle("-fx-background-color:white; -fx-background-radius:8; -fx-border-color:#dde4f0; -fx-border-radius:8;");
        return box;
    }

    // ── SERMONS TAB ───────────────────────────────────────────────────────────
    private VBox buildSermonsTab() {
        VBox pane = new VBox(14);
        pane.setPadding(new Insets(20));

        Label title = UIHelper.heading("🎙  Sermon Management");

        TextField searchF = UIHelper.styledField("Search by title, preacher or category...");
        searchF.setPrefWidth(300);
        Button searchBtn = UIHelper.primaryButton("Search");

        TableView<Sermon> table = buildSermonTable();

        searchBtn.setOnAction(e -> {
            String q = searchF.getText().trim();
            table.setItems(FXCollections.observableArrayList(
                q.isEmpty() ? sermonDAO.getAll() : sermonDAO.search(q)));
        });

        table.setItems(FXCollections.observableArrayList(sermonDAO.getAll()));

        Button addBtn    = UIHelper.goldButton("+ Upload Sermon");
        Button editBtn   = UIHelper.primaryButton("✏ Edit");
        Button deleteBtn = UIHelper.dangerButton("🗑 Delete");

        addBtn.setOnAction(e -> showSermonDialog(null, table));
        editBtn.setOnAction(e -> {
            Sermon sel = table.getSelectionModel().getSelectedItem();
            if (sel == null) { UIHelper.showError("Select","Pick a sermon first."); return; }
            showSermonDialog(sel, table);
        });
        deleteBtn.setOnAction(e -> {
            Sermon sel = table.getSelectionModel().getSelectedItem();
            if (sel == null) { UIHelper.showError("Select","Pick a sermon first."); return; }
            if (UIHelper.confirm("Delete","Delete \"" + sel.getTitle() + "\"?")) {
                sermonDAO.delete(sel.getId());
                table.setItems(FXCollections.observableArrayList(sermonDAO.getAll()));
            }
        });

        HBox topBar    = new HBox(10, searchF, searchBtn);
        HBox actionBar = new HBox(10, addBtn, editBtn, deleteBtn);

        pane.getChildren().addAll(title, topBar, table, actionBar);
        return pane;
    }

    private TableView<Sermon> buildSermonTable() {
        TableView<Sermon> t = new TableView<>();
        t.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY);
        t.setPrefHeight(380);

        TableColumn<Sermon,String> titleC    = col("Title",    "title",    200);
        TableColumn<Sermon,String> preacherC = col("Preacher", "preacher", 160);
        TableColumn<Sermon,String> dateC     = col("Date",     "date",     100);
        TableColumn<Sermon,String> catC      = col("Category", "category", 110);
        TableColumn<Sermon,String> typeC     = col("Media",    "mediaType", 80);

        t.getColumns().addAll(titleC, preacherC, dateC, catC, typeC);
        return t;
    }

    private void showSermonDialog(Sermon existing, TableView<Sermon> table) {
        boolean edit = existing != null;
        Stage d = new Stage();
        d.setTitle(edit ? "Edit Sermon" : "Upload Sermon");

        VBox box = new VBox(12);
        box.setPadding(new Insets(24));
        box.setPrefWidth(420);

        TextField titleF    = UIHelper.styledField("Sermon title");
        TextField preacherF = UIHelper.styledField("Preacher name");
        TextField dateF     = UIHelper.styledField("Date (YYYY-MM-DD)");
        TextField urlF      = UIHelper.styledField("Media URL (YouTube / Drive / file path)");
        TextArea  descF     = UIHelper.styledArea("Brief description", 3);

        ComboBox<String> catBox  = new ComboBox<>();
        catBox.getItems().addAll("Faith","Prayer","Salvation","Holy Spirit","Family","Worship","Prophecy","Other");
        catBox.setPromptText("Category");

        ComboBox<String> typeBox = new ComboBox<>();
        typeBox.getItems().addAll("Audio","Video","Document","YouTube");
        typeBox.setPromptText("Media type");

        if (edit) {
            titleF.setText(existing.getTitle());
            preacherF.setText(existing.getPreacher());
            dateF.setText(existing.getDate());
            urlF.setText(existing.getMediaUrl() != null ? existing.getMediaUrl() : "");
            descF.setText(existing.getDescription());
            catBox.setValue(existing.getCategory());
            typeBox.setValue(existing.getMediaType());
        }

        Button saveBtn = UIHelper.primaryButton(edit ? "Save Changes" : "Upload");
        saveBtn.setMaxWidth(Double.MAX_VALUE);

        saveBtn.setOnAction(e -> {
            if (titleF.getText().isEmpty() || preacherF.getText().isEmpty()) {
                UIHelper.showError("Required","Title and preacher are required."); return;
            }
            Sermon s = edit ? existing : new Sermon(0,"","","","","","","");
            s.setTitle(titleF.getText().trim());
            s.setPreacher(preacherF.getText().trim());
            s.setDate(dateF.getText().trim());
            s.setCategory(catBox.getValue());
            s.setMediaType(typeBox.getValue());
            s.setMediaUrl(urlF.getText().trim());
            s.setDescription(descF.getText().trim());

            boolean ok = edit ? sermonDAO.update(s) : sermonDAO.add(s);
            if (ok) {
                table.setItems(FXCollections.observableArrayList(sermonDAO.getAll()));
                d.close();
                UIHelper.showInfo("Saved", (edit ? "Sermon updated." : "Sermon uploaded successfully!"));
            }
        });

        box.getChildren().addAll(
            UIHelper.heading(edit ? "Edit Sermon" : "Upload Sermon"),
            new Label("Title"),    titleF,
            new Label("Preacher"), preacherF,
            new Label("Date"),     dateF,
            new Label("Category"), catBox,
            new Label("Media Type"), typeBox,
            new Label("Media URL"), urlF,
            new Label("Description"), descF,
            saveBtn
        );

        d.setScene(new javafx.scene.Scene(new ScrollPane(box)));
        d.initOwner(stage);
        d.showAndWait();
    }

    // ── GIVING TAB ────────────────────────────────────────────────────────────
    private VBox buildGivingTab() {
        VBox pane = new VBox(14);
        pane.setPadding(new Insets(20));

        Label title = UIHelper.heading("💛  Giving & Transactions");

        // MTN / Airtel account info card
        HBox accountInfo = new HBox(20,
            card(new Label("📱 MTN Mobile Money"),
                 new Label("Account: +25676334436"),
                 new Label("Name: Okurut Ambrose")),
            card(new Label("📱 Airtel Money"),
                 new Label("Account: +256756334436"),
                 new Label("Name: Okurut Ambrose"))
        );

        TableView<Giving> table = new TableView<>();
        table.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY);
        table.setPrefHeight(340);

        TableColumn<Giving,String>  nameC   = col("Member",  "memberName",   160);
        TableColumn<Giving,String>  phoneC  = col("Phone",   "phone",        120);
        TableColumn<Giving,String>  typeC   = col("Type",    "givingType",   130);
        TableColumn<Giving,String>  amtC    = new TableColumn<>("Amount");
        amtC.setCellValueFactory(d -> new javafx.beans.property.SimpleStringProperty(
            d.getValue().getAmountFormatted()));
        amtC.setPrefWidth(120);
        TableColumn<Giving,String>  methodC = col("Method",  "paymentMethod", 110);
        TableColumn<Giving,String>  statusC = col("Status",  "status",        90);
        TableColumn<Giving,String>  dateC   = col("Date",    "created",       140);

        table.getColumns().addAll(nameC, phoneC, typeC, amtC, methodC, statusC, dateC);
        table.setItems(FXCollections.observableArrayList(givingDAO.getAll()));

        // Status update bar
        ComboBox<String> statusBox = new ComboBox<>();
        statusBox.getItems().addAll("PENDING","COMPLETED","FAILED");
        statusBox.setPromptText("Update status");
        TextField txnIdF = UIHelper.styledField("Transaction ID");
        txnIdF.setPrefWidth(200);

        Button updateBtn = UIHelper.primaryButton("Update");
        updateBtn.setOnAction(e -> {
            Giving sel = table.getSelectionModel().getSelectedItem();
            if (sel == null || statusBox.getValue() == null) {
                UIHelper.showError("Select","Select a record and new status."); return;
            }
            givingDAO.updateStatus(sel.getId(), statusBox.getValue(), txnIdF.getText().trim());
            table.setItems(FXCollections.observableArrayList(givingDAO.getAll()));
            UIHelper.showInfo("Updated","Transaction status updated.");
        });

        HBox updateBar = new HBox(10, new Label("Selected:"), statusBox, txnIdF, updateBtn);
        updateBar.setAlignment(Pos.CENTER_LEFT);

        Label totalLabel = new Label("Grand Total Received: " +
            String.format("UGX %,.0f", givingDAO.getGrandTotal()));
        totalLabel.setFont(Font.font("System", FontWeight.BOLD, 15));
        totalLabel.setStyle("-fx-text-fill:" + UIHelper.SUCCESS + ";");

        pane.getChildren().addAll(title, accountInfo, table, updateBar, totalLabel);
        return pane;
    }

    // ── PRAYER TAB ────────────────────────────────────────────────────────────
    private VBox buildPrayerTab() {
        VBox pane = new VBox(14);
        pane.setPadding(new Insets(20));

        Label title = UIHelper.heading("🙏  Prayer Requests");

        TableView<PrayerRequest> table = new TableView<>();
        table.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY);
        table.setPrefHeight(320);

        TableColumn<PrayerRequest,String> nameC    = col("Member",   "memberName",  140);
        TableColumn<PrayerRequest,String> catC     = col("Category", "category",    110);
        TableColumn<PrayerRequest,String> visC     = col("Visibility","visibility",  90);
        TableColumn<PrayerRequest,String> statusC  = col("Status",   "status",       90);
        TableColumn<PrayerRequest,String> reqC     = col("Request",  "request",     260);
        TableColumn<PrayerRequest,String> dateC    = col("Date",     "created",     130);

        table.getColumns().addAll(nameC, catC, visC, statusC, reqC, dateC);
        table.setItems(FXCollections.observableArrayList(prayerDAO.getAll()));

        // Respond panel
        ComboBox<String> responseBox = new ComboBox<>();
        responseBox.getItems().addAll("PENDING","PRAYED FOR","ANSWERED");
        responseBox.setPromptText("Mark as...");
        TextArea noteArea = UIHelper.styledArea("Pastoral note to member (optional)", 2);

        Button respondBtn = UIHelper.primaryButton("Submit Response");
        respondBtn.setOnAction(e -> {
            PrayerRequest sel = table.getSelectionModel().getSelectedItem();
            if (sel == null || responseBox.getValue() == null) {
                UIHelper.showError("Select","Select a request and a status."); return;
            }
            prayerDAO.updateStatus(sel.getId(), responseBox.getValue(), noteArea.getText().trim());
            table.setItems(FXCollections.observableArrayList(prayerDAO.getAll()));
            noteArea.clear();
            UIHelper.showInfo("Saved","Prayer request updated. 🙏");
        });

        HBox responseBar = new HBox(12, responseBox, respondBtn);
        responseBar.setAlignment(Pos.CENTER_LEFT);

        pane.getChildren().addAll(title, table, UIHelper.subheading("Respond to Selected Request:"),
            noteArea, responseBar);
        return pane;
    }

    // ── MINISTRIES TAB ────────────────────────────────────────────────────────
    private VBox buildMinistriesTab() {
        VBox pane = new VBox(14);
        pane.setPadding(new Insets(20));

        Label title = UIHelper.heading("⛪  Ministry Management");

        TableView<Ministry> table = new TableView<>();
        table.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY);
        table.setPrefHeight(320);

        TableColumn<Ministry,String> nameC = col("Ministry",    "name",        180);
        TableColumn<Ministry,String> leadC = col("Leader",      "leader",      180);
        TableColumn<Ministry,String> descC = col("Description", "description", 340);

        table.getColumns().addAll(nameC, leadC, descC);
        table.setItems(FXCollections.observableArrayList(ministryDAO.getAll()));

        Button addBtn    = UIHelper.goldButton("+ Add Ministry");
        Button editBtn   = UIHelper.primaryButton("✏ Edit");
        Button deleteBtn = UIHelper.dangerButton("🗑 Delete");

        addBtn.setOnAction(e -> showMinistryDialog(null, table));
        editBtn.setOnAction(e -> {
            Ministry sel = table.getSelectionModel().getSelectedItem();
            if (sel == null) { UIHelper.showError("Select","Pick a ministry first."); return; }
            showMinistryDialog(sel, table);
        });
        deleteBtn.setOnAction(e -> {
            Ministry sel = table.getSelectionModel().getSelectedItem();
            if (sel == null) { UIHelper.showError("Select","Pick a ministry first."); return; }
            if (UIHelper.confirm("Delete","Delete ministry \"" + sel.getName() + "\"?")) {
                ministryDAO.delete(sel.getId());
                table.setItems(FXCollections.observableArrayList(ministryDAO.getAll()));
            }
        });

        HBox actionBar = new HBox(10, addBtn, editBtn, deleteBtn);
        pane.getChildren().addAll(title, table, actionBar);
        return pane;
    }

    private void showMinistryDialog(Ministry existing, TableView<Ministry> table) {
        boolean edit = existing != null;
        Stage d = new Stage();
        d.setTitle(edit ? "Edit Ministry" : "Add Ministry");

        VBox box = new VBox(12);
        box.setPadding(new Insets(24));
        box.setPrefWidth(380);

        TextField nameF = UIHelper.styledField("Ministry name");
        TextField leadF = UIHelper.styledField("Ministry leader");
        TextArea  descF = UIHelper.styledArea("Description", 3);

        if (edit) {
            nameF.setText(existing.getName());
            leadF.setText(existing.getLeader());
            descF.setText(existing.getDescription());
        }

        Button saveBtn = UIHelper.primaryButton(edit ? "Save Changes" : "Add Ministry");
        saveBtn.setMaxWidth(Double.MAX_VALUE);

        saveBtn.setOnAction(e -> {
            if (nameF.getText().isEmpty()) { UIHelper.showError("Required","Ministry name is required."); return; }
            Ministry m = edit ? existing : new Ministry(0,"","","",null);
            m.setName(nameF.getText().trim());
            m.setLeader(leadF.getText().trim());
            m.setDescription(descF.getText().trim());
            boolean ok = edit ? ministryDAO.update(m) : ministryDAO.add(m);
            if (ok) {
                table.setItems(FXCollections.observableArrayList(ministryDAO.getAll()));
                d.close();
            }
        });

        box.getChildren().addAll(
            UIHelper.heading(edit ? "Edit Ministry" : "New Ministry"),
            new Label("Ministry Name"), nameF,
            new Label("Leader"),        leadF,
            new Label("Description"),   descF,
            saveBtn
        );
        d.setScene(new javafx.scene.Scene(box));
        d.initOwner(stage);
        d.showAndWait();
    }

    // ── LEADERSHIP TAB ────────────────────────────────────────────────────────
    private ScrollPane buildLeadershipTab() {
        VBox pane = new VBox(20);
        pane.setPadding(new Insets(24));

        Label title = UIHelper.heading("👑  Church Leadership");

        VBox seniorCard = leaderCard(
            "Rev. Dr. Emmanuel Akatukunda",
            "Senior Pastor",
            "+256706062966",
            "+256788758696",
            "Leading the congregation in faith, vision and spiritual growth."
        );

        VBox assistantCard = leaderCard(
            "Pr. Gideon Onyait",
            "Assistant Pastor",
            "+256772566848",
            "+256754247261",
            "Supporting pastoral work, discipleship and ministry coordination."
        );

        Label payTitle = UIHelper.subheading("💰  Mobile Money Giving Accounts");
        VBox payCard = card(
            buildPayRow("MTN Mobile Money", "+25676334436", "Okurut Ambrose"),
            buildPayRow("Airtel Money",     "+256756334436","Okurut Ambrose")
        );

        pane.getChildren().addAll(title,
            UIHelper.subheading("Senior Leadership"),
            seniorCard, assistantCard,
            UIHelper.separator(), payTitle, payCard
        );

        ScrollPane scroll = new ScrollPane(pane);
        scroll.setFitToWidth(true);
        return scroll;
    }

    private VBox leaderCard(String name, String role, String phone1, String phone2, String bio) {
        VBox box = new VBox(6);
        box.setPadding(new Insets(16));
        box.setStyle("""
            -fx-background-color:white;
            -fx-background-radius:10;
            -fx-border-color:%s;
            -fx-border-width:0 0 0 5;
            -fx-border-radius:0;
        """.formatted(UIHelper.GOLD));

        Label nameLbl = new Label("✝  " + name);
        nameLbl.setFont(Font.font("System", FontWeight.BOLD, 16));
        nameLbl.setStyle("-fx-text-fill:" + UIHelper.ROYAL_BLUE + ";");

        Label roleLbl = UIHelper.badge(role, UIHelper.ROYAL_BLUE, "white");
        Label phone1Lbl = new Label("📞 " + phone1);
        Label phone2Lbl = new Label("📞 " + phone2);
        Label bioLbl    = UIHelper.muted(bio);

        box.getChildren().addAll(nameLbl, roleLbl, phone1Lbl, phone2Lbl, bioLbl);
        return box;
    }

    private HBox buildPayRow(String provider, String number, String name) {
        HBox row = new HBox(16);
        row.setAlignment(Pos.CENTER_LEFT);
        row.setPadding(new Insets(8, 0, 8, 0));
        Label prov = new Label(provider);
        prov.setPrefWidth(160);
        prov.setStyle("-fx-font-weight:bold;");
        Label num  = new Label(number);
        num.setPrefWidth(150);
        Label nm   = new Label(name);
        nm.setStyle("-fx-text-fill:" + UIHelper.TEXT_MUTED + ";");
        row.getChildren().addAll(prov, num, nm);
        return row;
    }

    // ── Helpers ───────────────────────────────────────────────────────────────
    @SuppressWarnings("unchecked")
    private <T> TableColumn<T, String> col(String label, String prop, double width) {
        TableColumn<T, String> c = new TableColumn<>(label);
        c.setCellValueFactory(new PropertyValueFactory<>(prop));
        c.setPrefWidth(width);
        return c;
    }
}
