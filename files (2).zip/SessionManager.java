package com.permbandaschurch.utils;

import android.content.Context;
import android.content.SharedPreferences;

// ══════════════════════════════════════════════════════════════════════════════
//  SessionManager — persists login state via SharedPreferences
// ══════════════════════════════════════════════════════════════════════════════
public class SessionManager {

    private static final String PREF_NAME   = "PermBandaSession";
    private static final String KEY_LOGGED  = "isLoggedIn";
    private static final String KEY_NAME    = "userName";
    private static final String KEY_EMAIL   = "userEmail";

    private final SharedPreferences prefs;
    private final SharedPreferences.Editor editor;

    public SessionManager(Context context) {
        prefs  = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
        editor = prefs.edit();
    }

    public void createSession(String name, String email) {
        editor.putBoolean(KEY_LOGGED, true);
        editor.putString(KEY_NAME,   name);
        editor.putString(KEY_EMAIL,  email);
        editor.apply();
    }

    public boolean isLoggedIn() { return prefs.getBoolean(KEY_LOGGED, false); }
    public String getUserName() { return prefs.getString(KEY_NAME, "Member"); }
    public String getUserEmail(){ return prefs.getString(KEY_EMAIL, ""); }

    public void logout() {
        editor.clear();
        editor.apply();
    }
}
