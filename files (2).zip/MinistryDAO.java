package permbandaschurch.dao;

import permbandaschurch.model.Ministry;
import java.sql.*;
import java.util.*;

public class MinistryDAO {
    private Connection conn() throws SQLException {
        return DatabaseManager.getInstance().getConnection();
    }

    public List<Ministry> getAll() {
        List<Ministry> list = new ArrayList<>();
        try (Statement st = conn().createStatement();
             ResultSet rs = st.executeQuery("SELECT * FROM ministries ORDER BY name")) {
            while (rs.next()) list.add(map(rs));
        } catch (SQLException e) { e.printStackTrace(); }
        return list;
    }

    public boolean add(Ministry m) {
        String sql = "INSERT INTO ministries(name,description,leader) VALUES(?,?,?)";
        try (PreparedStatement ps = conn().prepareStatement(sql)) {
            ps.setString(1,m.getName()); ps.setString(2,m.getDescription());
            ps.setString(3,m.getLeader()); ps.executeUpdate(); return true;
        } catch (SQLException e) { e.printStackTrace(); return false; }
    }

    public boolean update(Ministry m) {
        String sql = "UPDATE ministries SET name=?,description=?,leader=? WHERE id=?";
        try (PreparedStatement ps = conn().prepareStatement(sql)) {
            ps.setString(1,m.getName()); ps.setString(2,m.getDescription());
            ps.setString(3,m.getLeader()); ps.setInt(4,m.getId());
            ps.executeUpdate(); return true;
        } catch (SQLException e) { e.printStackTrace(); return false; }
    }

    public boolean delete(int id) {
        try (PreparedStatement ps = conn().prepareStatement("DELETE FROM ministries WHERE id=?")) {
            ps.setInt(1,id); ps.executeUpdate(); return true;
        } catch (SQLException e) { e.printStackTrace(); return false; }
    }

    private Ministry map(ResultSet rs) throws SQLException {
        return new Ministry(rs.getInt("id"), rs.getString("name"),
            rs.getString("description"), rs.getString("leader"), rs.getString("image_url"));
    }
}
