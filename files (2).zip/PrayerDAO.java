package permbandaschurch.dao;

import permbandaschurch.model.*;
import java.sql.*;
import java.util.*;

public class PrayerDAO {
    private Connection conn() throws SQLException {
        return DatabaseManager.getInstance().getConnection();
    }

    public List<PrayerRequest> getAll() {
        List<PrayerRequest> list = new ArrayList<>();
        try (Statement st = conn().createStatement();
             ResultSet rs = st.executeQuery("SELECT * FROM prayer_requests ORDER BY created DESC")) {
            while (rs.next()) list.add(map(rs));
        } catch (SQLException e) { e.printStackTrace(); }
        return list;
    }

    public boolean add(String name, String category, String request, String visibility) {
        String sql = "INSERT INTO prayer_requests(member_name,category,request,visibility) VALUES(?,?,?,?)";
        try (PreparedStatement ps = conn().prepareStatement(sql)) {
            ps.setString(1,name); ps.setString(2,category);
            ps.setString(3,request); ps.setString(4,visibility);
            ps.executeUpdate(); return true;
        } catch (SQLException e) { e.printStackTrace(); return false; }
    }

    public void updateStatus(int id, String status, String note) {
        try (PreparedStatement ps = conn().prepareStatement(
                "UPDATE prayer_requests SET status=?,admin_note=? WHERE id=?")) {
            ps.setString(1,status); ps.setString(2,note); ps.setInt(3,id);
            ps.executeUpdate();
        } catch (SQLException e) { e.printStackTrace(); }
    }

    public int countPending() {
        try (Statement st = conn().createStatement();
             ResultSet rs = st.executeQuery("SELECT COUNT(*) FROM prayer_requests WHERE status='PENDING'")) {
            return rs.next() ? rs.getInt(1) : 0;
        } catch (SQLException e) { return 0; }
    }

    private PrayerRequest map(ResultSet rs) throws SQLException {
        return new PrayerRequest(rs.getInt("id"), rs.getString("member_name"),
            rs.getString("category"), rs.getString("request"), rs.getString("visibility"),
            rs.getString("status"), rs.getString("admin_note"), rs.getString("created"));
    }
}
