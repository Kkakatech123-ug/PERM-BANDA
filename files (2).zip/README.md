# PERM BANDA CHURCH — Complete Application Suite
### Desktop Admin Panel (JavaFX) + Android Member App (Java)

---

## Project Structure

```
PermBandaChurch/
├── desktop/                          ← JavaFX Admin Panel (NetBeans)
│   └── src/permbandaschurch/
│       ├── MainApp.java              ← Entry point
│       ├── dao/
│       │   ├── DatabaseManager.java  ← SQLite setup + seed data
│       │   ├── AdminDAO.java         ← Admin login
│       │   ├── SermonDAO.java        ← Sermon CRUD
│       │   ├── GivingDAO.java        ← Giving records
│       │   ├── PrayerDAO.java        ← Prayer requests
│       │   └── MinistryDAO.java      ← Ministries CRUD
│       ├── model/
│       │   ├── Admin.java
│       │   ├── Sermon.java
│       │   ├── Giving.java
│       │   ├── PrayerRequest.java
│       │   └── Ministry.java
│       ├── ui/
│       │   ├── LoginScreen.java      ← Church-branded login
│       │   └── AdminDashboard.java   ← Full admin panel (6 tabs)
│       └── util/
│           ├── UIHelper.java         ← Brand colors + UI components
│           └── Session.java          ← Admin session state
│
└── android/                          ← Android Member App (Android Studio)
    └── app/src/main/
        ├── AndroidManifest.xml
        ├── java/com/permbandaschurch/
        │   ├── activities/
        │   │   ├── SplashActivity.java
        │   │   ├── LoginActivity.java
        │   │   ├── RegisterActivity.java
        │   │   ├── HomeActivity.java        ← Dashboard with 6 quick actions
        │   │   ├── GivingActivity.java      ← MTN MoMo + Airtel giving
        │   │   ├── PrayerActivity.java      ← Prayer request submission
        │   │   └── OtherActivities.java     ← Sermons, Ministries, Leadership, Profile
        │   ├── network/
        │   │   └── PaymentService.java      ← MTN + Airtel API integration
        │   └── utils/
        │       ├── SessionManager.java      ← SharedPreferences session
        │       └── Validator.java
        └── res/
            ├── layout/
            │   ├── activity_splash.xml
            │   ├── activity_login.xml
            │   ├── activity_home.xml
            │   ├── activity_giving.xml
            │   └── activity_prayer.xml
            └── values/
                ├── colors.xml               ← Church brand palette
                ├── strings.xml              ← App strings + contacts
                └── styles.xml              ← Material themes
```

---

## Desktop Setup (NetBeans)

### Step 1 — Download JARs
| Library       | Download                                      |
|---------------|-----------------------------------------------|
| JavaFX SDK 17+| https://gluonhq.com/products/javafx/          |
| SQLite JDBC   | https://github.com/xerial/sqlite-jdbc/releases|

### Step 2 — NetBeans Project
1. File > New Project > Java with Ant > Java Application
2. Add sqlite-jdbc JAR and JavaFX library to Libraries
3. Set Main Class: `permbandaschurch.MainApp`
4. Set VM Options:
```
--module-path "C:\path\to\javafx-sdk\lib" --add-modules javafx.controls,javafx.fxml
```

### Step 3 — Run (F6)
Database `permbandaschurch.db` is created automatically on first run.

### Admin Credentials
| Username | Password        | Role       |
|----------|-----------------|------------|
| admin    | permchurch2024  | Superadmin |
| pastor   | pastor123       | Pastor     |

---

## Android Setup (Android Studio)

### Step 1 — Open Project
1. Open Android Studio → Open an existing project
2. Select the `android/` folder

### Step 2 — Sync Gradle
Click "Sync Now" when prompted. All dependencies download automatically.

### Step 3 — Run on Device / Emulator
Press the green ▶ Play button. Min SDK is Android 7.0 (API 24).

### Step 4 — Enable Real Payments
Open `PaymentService.java` and replace the demo simulation block with:
- Real MTN MoMo API calls (sandbox first, then production)
- Real Airtel Money API calls
- Your credentials from the developer portals:
  - MTN: https://momodeveloper.mtn.com
  - Airtel: https://developers.airtel.africa

---

## Payment Routing
| Provider    | Account Number | Account Name  |
|-------------|----------------|---------------|
| MTN MoMo    | +25676334436   | Okurut Ambrose|
| Airtel Money| +256756334436  | Okurut Ambrose|

---

## Church Leadership
| Name                            | Role               | Phone                          |
|---------------------------------|--------------------|--------------------------------|
| Rev. Dr. Emmanuel Akatukunda    | Senior Pastor      | +256706062966 / +256788758696  |
| Pr. Gideon Onyait               | Assistant Pastor   | +256772566848 / +256754247261  |

---

## Features

### Desktop Admin Panel
- Secure admin login with role-based access
- Overview dashboard with stats (sermons, giving, prayer requests)
- Sermon management — upload, edit, delete with media URLs
- Giving & transactions — view all, update status, see totals
- Prayer request moderation — respond, mark prayed/answered
- Ministry management — add, edit, delete ministries
- Leadership contacts page

### Android Member App
- Splash screen with church branding
- Login / Register / Guest access
- Home dashboard with 6 quick action tiles
- Digital giving — MTN MoMo + Airtel Money, all 5 giving types
- Prayer request submission (private or public)
- Sermon library with YouTube / media links
- Ministries listing with leader details
- Leadership page with Call + WhatsApp buttons
- Auto-route payments to church accounts

---

## Future Enhancements
- Push notifications (Firebase FCM)
- Bible & daily devotionals
- Event ticketing
- Attendance tracking
- Multi-language (Luganda, Acholi, English)
- iOS app via Flutter migration
