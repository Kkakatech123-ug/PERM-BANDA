package com.permbandaschurch.activities;

import android.os.Bundle;
import android.view.View;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;
import com.google.android.material.textfield.TextInputEditText;
import com.permbandaschurch.R;
import com.permbandaschurch.utils.SessionManager;

public class PrayerActivity extends AppCompatActivity {

    private TextInputEditText etName, etRequest;
    private Spinner           spinnerCategory;
    private RadioGroup        rgVisibility;
    private TextView          tvError;
    private SessionManager    session;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_prayer);

        session       = new SessionManager(this);
        etName        = findViewById(R.id.etName);
        etRequest     = findViewById(R.id.etRequest);
        spinnerCategory = findViewById(R.id.spinnerCategory);
        rgVisibility  = findViewById(R.id.rgVisibility);
        tvError       = findViewById(R.id.tvError);

        // Category spinner
        String[] categories = {"Health & Healing","Family","Finances","Salvation","Thanksgiving","Marriage","Career","Other"};
        spinnerCategory.setAdapter(new ArrayAdapter<>(
            this, android.R.layout.simple_spinner_dropdown_item, categories));

        etName.setText(session.getUserName());

        findViewById(R.id.btnSubmit).setOnClickListener(v -> submitPrayer());

        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setTitle("Prayer Requests");
        }
    }

    private void submitPrayer() {
        String name     = etName.getText()    != null ? etName.getText().toString().trim()    : "";
        String request  = etRequest.getText() != null ? etRequest.getText().toString().trim() : "";
        String category = spinnerCategory.getSelectedItem().toString();
        String visibility = (rgVisibility.getCheckedRadioButtonId() == R.id.rbPublic)
            ? "public" : "private";

        if (name.isEmpty())    { showError("Please enter your name.");           return; }
        if (request.isEmpty()) { showError("Please describe your prayer request."); return; }

        tvError.setVisibility(View.GONE);

        // TODO: Send to backend API / Firebase
        // For now: show confirmation
        new androidx.appcompat.app.AlertDialog.Builder(this)
            .setTitle("🙏 Prayer Request Submitted")
            .setMessage("Dear " + name + ",\n\nYour prayer request has been received.\n\n" +
                "Category: " + category + "\nVisibility: " + visibility +
                "\n\nOur pastors will pray with you. God bless you! 🙏")
            .setPositiveButton("Amen 🙏", (d, w) -> { d.dismiss(); finish(); })
            .show();
    }

    private void showError(String msg) {
        tvError.setText(msg); tvError.setVisibility(View.VISIBLE);
    }

    @Override
    public boolean onSupportNavigateUp() { finish(); return true; }
}
