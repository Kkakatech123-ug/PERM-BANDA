package permbandaschurch.dao;

import permbandaschurch.model.*;
import java.sql.*;
import java.util.*;

// ═══════════════════════════════════════════════════════════════
//  GivingDAO
// ═══════════════════════════════════════════════════════════════
public class GivingDAO {
    private Connection conn() throws SQLException {
        return DatabaseManager.getInstance().getConnection();
    }

    public List<Giving> getAll() {
        List<Giving> list = new ArrayList<>();
        try (Statement st = conn().createStatement();
             ResultSet rs = st.executeQuery("SELECT * FROM givings ORDER BY created DESC")) {
            while (rs.next()) list.add(map(rs));
        } catch (SQLException e) { e.printStackTrace(); }
        return list;
    }

    public int addGiving(String memberName, String phone, double amount,
                         String type, String method) {
        String sql = "INSERT INTO givings(member_name,phone,amount_ugx,giving_type,payment_method,status) VALUES(?,?,?,?,?,'PENDING')";
        try (PreparedStatement ps = conn().prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            ps.setString(1,memberName); ps.setString(2,phone);
            ps.setDouble(3,amount); ps.setString(4,type); ps.setString(5,method);
            ps.executeUpdate();
            ResultSet keys = ps.getGeneratedKeys();
            return keys.next() ? keys.getInt(1) : -1;
        } catch (SQLException e) { e.printStackTrace(); return -1; }
    }

    public void updateStatus(int id, String status, String txnId) {
        try (PreparedStatement ps = conn().prepareStatement(
                "UPDATE givings SET status=?,transaction_id=? WHERE id=?")) {
            ps.setString(1,status); ps.setString(2,txnId); ps.setInt(3,id);
            ps.executeUpdate();
        } catch (SQLException e) { e.printStackTrace(); }
    }

    public double getTotalByType(String type) {
        String sql = "SELECT SUM(amount_ugx) FROM givings WHERE giving_type=? AND status='COMPLETED'";
        try (PreparedStatement ps = conn().prepareStatement(sql)) {
            ps.setString(1,type);
            ResultSet rs = ps.executeQuery();
            return rs.next() ? rs.getDouble(1) : 0;
        } catch (SQLException e) { return 0; }
    }

    public double getGrandTotal() {
        try (Statement st = conn().createStatement();
             ResultSet rs = st.executeQuery("SELECT SUM(amount_ugx) FROM givings WHERE status='COMPLETED'")) {
            return rs.next() ? rs.getDouble(1) : 0;
        } catch (SQLException e) { return 0; }
    }

    private Giving map(ResultSet rs) throws SQLException {
        return new Giving(rs.getInt("id"), rs.getString("member_name"), rs.getString("phone"),
            rs.getDouble("amount_ugx"), rs.getString("giving_type"), rs.getString("payment_method"),
            rs.getString("transaction_id"), rs.getString("status"), rs.getString("created"));
    }
}
