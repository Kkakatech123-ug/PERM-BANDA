package permbandaschurch.ui;

import permbandaschurch.dao.AdminDAO;
import permbandaschurch.model.Admin;
import permbandaschurch.util.*;
import javafx.geometry.*;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.text.*;
import javafx.stage.Stage;

public class LoginScreen {

    private final Stage stage;
    private final AdminDAO adminDAO = new AdminDAO();

    public LoginScreen(Stage stage) { this.stage = stage; }

    public void show() {
        stage.setTitle("PERM BANDA CHURCH — Admin Login");

        // ── Left: Church Identity Panel ──────────────────────────────────
        VBox leftPanel = new VBox(18);
        leftPanel.setAlignment(Pos.CENTER);
        leftPanel.setPrefWidth(300);
        leftPanel.setPadding(new Insets(40));
        leftPanel.setStyle("-fx-background-color: " + UIHelper.ROYAL_BLUE + ";");

        // Cross icon
        Label cross = new Label("✝");
        cross.setFont(Font.font("System", 52));
        cross.setStyle("-fx-text-fill: " + UIHelper.GOLD + ";");

        Label churchName = new Label("PERM BANDA");
        churchName.setFont(Font.font("System", FontWeight.BOLD, 22));
        churchName.setStyle("-fx-text-fill: " + UIHelper.GOLD + ";");

        Label churchSub = new Label("CHURCH");
        churchSub.setFont(Font.font("System", FontWeight.BOLD, 18));
        churchSub.setStyle("-fx-text-fill: white;");

        Separator sep = new Separator();
        sep.setStyle("-fx-background-color: " + UIHelper.GOLD + "; -fx-opacity: 0.4;");

        Label tagline = new Label("\"Faith  •  Hope  •  Love\"");
        tagline.setStyle("-fx-text-fill: #a8c4e8; -fx-font-style: italic; -fx-font-size: 13px;");

        Label hint = new Label("Admin Portal\nUsername: admin\nPassword: permchurch2024");
        hint.setTextAlignment(TextAlignment.CENTER);
        hint.setStyle("-fx-text-fill: #7aabe0; -fx-font-size: 11px;");

        leftPanel.getChildren().addAll(cross, churchName, churchSub, sep, tagline, hint);

        // ── Right: Login Form ─────────────────────────────────────────────
        VBox rightPanel = new VBox(14);
        rightPanel.setAlignment(Pos.CENTER);
        rightPanel.setPadding(new Insets(48));
        rightPanel.setPrefWidth(340);
        rightPanel.setStyle("-fx-background-color: white;");

        Label title = new Label("Admin Sign In");
        title.setFont(Font.font("System", FontWeight.BOLD, 22));
        title.setStyle("-fx-text-fill: " + UIHelper.ROYAL_BLUE + ";");

        Label subtitle = UIHelper.muted("PERM BANDA CHURCH Management");

        TextField usernameField = UIHelper.styledField("Admin username");
        PasswordField passwordField = UIHelper.styledPassword("Password");

        Button loginBtn = UIHelper.primaryButton("Sign In  →");
        loginBtn.setMaxWidth(Double.MAX_VALUE);

        Label errorLabel = new Label();
        errorLabel.setStyle("-fx-text-fill:" + UIHelper.DANGER + "; -fx-font-size:12px;");

        loginBtn.setOnAction(e -> {
            String u = usernameField.getText().trim();
            String p = passwordField.getText();
            if (u.isEmpty() || p.isEmpty()) {
                errorLabel.setText("Please enter your credentials."); return;
            }
            Admin admin = adminDAO.login(u, p);
            if (admin != null) {
                Session.getInstance().setCurrentAdmin(admin);
                new AdminDashboard(stage).show();
            } else {
                errorLabel.setText("Invalid username or password.");
            }
        });

        passwordField.setOnAction(e -> loginBtn.fire());

        rightPanel.getChildren().addAll(
            title, subtitle,
            new Label("Username"), usernameField,
            new Label("Password"), passwordField,
            errorLabel, loginBtn
        );

        HBox root = new HBox(leftPanel, rightPanel);
        stage.setScene(new Scene(root, 640, 420));
        stage.setResizable(false);
        stage.centerOnScreen();
        stage.show();
    }
}
