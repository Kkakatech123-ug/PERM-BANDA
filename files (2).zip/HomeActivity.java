package com.permbandaschurch.activities;

import android.content.Intent;
import android.os.Bundle;
import android.view.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import com.permbandaschurch.R;
import com.permbandaschurch.utils.SessionManager;

public class HomeActivity extends AppCompatActivity {

    private SessionManager session;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        session = new SessionManager(this);

        // Toolbar
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        // Welcome message
        android.widget.TextView tvWelcome = findViewById(R.id.tvWelcome);
        tvWelcome.setText("Welcome, " + session.getUserName() + " 🙏");

        // Quick action cards
        findViewById(R.id.cardGive).setOnClickListener(v ->
            startActivity(new Intent(this, GivingActivity.class)));

        findViewById(R.id.cardSermons).setOnClickListener(v ->
            startActivity(new Intent(this, SermonsActivity.class)));

        findViewById(R.id.cardPrayer).setOnClickListener(v ->
            startActivity(new Intent(this, PrayerActivity.class)));

        findViewById(R.id.cardMinistries).setOnClickListener(v ->
            startActivity(new Intent(this, MinistriesActivity.class)));

        findViewById(R.id.cardLeadership).setOnClickListener(v ->
            startActivity(new Intent(this, LeadershipActivity.class)));

        findViewById(R.id.cardYoutube).setOnClickListener(v ->
            startActivity(new Intent(this, SermonsActivity.class)));
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        menu.add(0, 1, 0, "My Profile");
        menu.add(0, 2, 1, "Logout");
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == 1) {
            startActivity(new Intent(this, ProfileActivity.class));
        } else if (item.getItemId() == 2) {
            session.logout();
            startActivity(new Intent(this, LoginActivity.class));
            finishAffinity();
        }
        return true;
    }
}
