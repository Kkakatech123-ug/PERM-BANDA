package com.permbandaschurch.activities;

import android.os.Bundle;
import android.view.View;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;
import com.google.android.material.textfield.TextInputEditText;
import com.permbandaschurch.R;
import com.permbandaschurch.network.PaymentService;
import com.permbandaschurch.utils.SessionManager;

public class GivingActivity extends AppCompatActivity {

    // ── Payment account constants ─────────────────────────────────────────────
    private static final String MTN_ACCOUNT    = "+25676334436";
    private static final String AIRTEL_ACCOUNT = "+256756334436";
    private static final String ACCOUNT_NAME   = "Okurut Ambrose";

    private TextInputEditText etName, etPhone, etAmount;
    private Spinner           spinnerGivingType;
    private RadioGroup        rgPaymentMethod;
    private RadioButton       rbMtn, rbAirtel;
    private TextView          tvError, tvAccountTitle, tvAccountNumber;
    private Button            btnGive;
    private SessionManager    session;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_giving);

        session = new SessionManager(this);

        // Bind views
        etName           = findViewById(R.id.etName);
        etPhone          = findViewById(R.id.etPhone);
        etAmount         = findViewById(R.id.etAmount);
        spinnerGivingType= findViewById(R.id.spinnerGivingType);
        rgPaymentMethod  = findViewById(R.id.rgPaymentMethod);
        rbMtn            = findViewById(R.id.rbMtn);
        rbAirtel         = findViewById(R.id.rbAirtel);
        tvError          = findViewById(R.id.tvError);
        tvAccountTitle   = findViewById(R.id.tvAccountTitle);
        tvAccountNumber  = findViewById(R.id.tvAccountNumber);
        btnGive          = findViewById(R.id.btnGive);

        // Giving types spinner
        String[] givingTypes = {
            "Tithe", "Offering", "Donation", "Thanksgiving", "First Fruit Offering"
        };
        ArrayAdapter<String> adapter = new ArrayAdapter<>(
            this, android.R.layout.simple_spinner_dropdown_item, givingTypes);
        spinnerGivingType.setAdapter(adapter);

        // Pre-fill name from session
        etName.setText(session.getUserName());

        // Update account display on provider change
        rgPaymentMethod.setOnCheckedChangeListener((group, id) -> {
            if (id == R.id.rbMtn) {
                tvAccountTitle.setText("MTN Mobile Money");
                tvAccountNumber.setText("Account: " + MTN_ACCOUNT);
            } else {
                tvAccountTitle.setText("Airtel Money");
                tvAccountNumber.setText("Account: " + AIRTEL_ACCOUNT);
            }
        });

        btnGive.setOnClickListener(v -> submitGiving());

        // Back button
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setTitle("Give");
        }
    }

    private void submitGiving() {
        String name   = etName.getText()   != null ? etName.getText().toString().trim()   : "";
        String phone  = etPhone.getText()  != null ? etPhone.getText().toString().trim()  : "";
        String amtStr = etAmount.getText() != null ? etAmount.getText().toString().trim() : "";

        // Validation
        if (name.isEmpty())  { showError("Please enter your name.");   return; }
        if (phone.isEmpty()) { showError("Please enter your phone number."); return; }
        if (amtStr.isEmpty()){ showError("Please enter an amount."); return; }

        double amount;
        try {
            amount = Double.parseDouble(amtStr);
            if (amount <= 0) { showError("Amount must be greater than 0."); return; }
        } catch (NumberFormatException e) {
            showError("Please enter a valid amount."); return;
        }

        tvError.setVisibility(View.GONE);
        btnGive.setEnabled(false);
        btnGive.setText("Processing...");

        String givingType = spinnerGivingType.getSelectedItem().toString();
        String provider   = rbMtn.isChecked() ? "MTN" : "AIRTEL";
        String targetAccount = rbMtn.isChecked() ? MTN_ACCOUNT : AIRTEL_ACCOUNT;

        // Normalise phone (0755... → 256755...)
        String normalisedPhone = phone.startsWith("0")
            ? "256" + phone.substring(1) : phone.replaceAll("^\\+","");

        // Initiate mobile money payment
        PaymentService.initiatePayment(
            normalisedPhone, amount, givingType, provider, targetAccount,
            new PaymentService.PaymentCallback() {
                @Override
                public void onSuccess(String transactionId) {
                    runOnUiThread(() -> {
                        btnGive.setEnabled(true);
                        btnGive.setText("Give Now 💛");
                        showSuccessDialog(givingType, amount, provider, transactionId);
                    });
                }
                @Override
                public void onFailure(String error) {
                    runOnUiThread(() -> {
                        btnGive.setEnabled(true);
                        btnGive.setText("Give Now 💛");
                        showError("Payment failed: " + error);
                    });
                }
            }
        );
    }

    private void showSuccessDialog(String type, double amount, String provider, String txnId) {
        new androidx.appcompat.app.AlertDialog.Builder(this)
            .setTitle("✅ Giving Received!")
            .setMessage(String.format(
                "Thank you for your %s!\n\nAmount: UGX %,.0f\nProvider: %s\nTransaction ID: %s\n\n" +
                "\"God loves a cheerful giver\" — 2 Corinthians 9:7",
                type, amount, provider, txnId))
            .setPositiveButton("Done", (d, w) -> {
                d.dismiss(); finish();
            })
            .setCancelable(false)
            .show();
    }

    private void showError(String msg) {
        tvError.setText(msg);
        tvError.setVisibility(View.VISIBLE);
    }

    @Override
    public boolean onSupportNavigateUp() { finish(); return true; }
}
