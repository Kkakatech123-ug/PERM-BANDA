package permbandaschurch;

import permbandaschurch.dao.DatabaseManager;
import permbandaschurch.ui.LoginScreen;
import javafx.application.Application;
import javafx.stage.Stage;

/**
 * PERM BANDA CHURCH — Desktop Admin Panel
 * Run in NetBeans: set VM options:
 *   --module-path "path/to/javafx-sdk/lib" --add-modules javafx.controls,javafx.fxml
 */
public class MainApp extends Application {

    @Override
    public void start(Stage primaryStage) throws Exception {
        DatabaseManager.getInstance().initializeDatabase();
        new LoginScreen(primaryStage).show();
    }

    public static void main(String[] args) {
        launch(args);
    }
}
